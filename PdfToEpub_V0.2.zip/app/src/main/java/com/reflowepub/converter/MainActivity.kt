package com.reflowepub.converter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var analyzeButton: Button
    private lateinit var result: TextView

    private var selectedUri: Uri? = null
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB"
            textSize = 28f
        }

        val subtitle = TextView(this).apply {
            text = "V0.2 — PDF analysis"
            textSize = 16f
        }

        val selectButton = Button(this).apply {
            text = "SELECT PDF"
            setOnClickListener { selectPdf() }
        }

        status = TextView(this).apply {
            text = "No PDF selected"
            textSize = 16f
        }

        analyzeButton = Button(this).apply {
            text = "ANALYZE PDF"
            isEnabled = false
            setOnClickListener { analyzePdf() }
        }

        result = TextView(this).apply {
            text = "Analysis results will appear here."
            textSize = 15f
            setTextIsSelectable(true)
        }

        val resultScroll = ScrollView(this).apply {
            addView(result)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(selectButton)
        root.addView(status)
        root.addView(analyzeButton)
        root.addView(resultScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        ))

        setContentView(root)
    }

    private fun selectPdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_PDF)
    }

    @Deprecated("Simple activity-result flow for V0.2")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_PDF && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            selectedUri = uri

            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers do not offer persistable permissions.
            }

            status.text = "Selected PDF:\n${uri.lastPathSegment ?: uri}"
            analyzeButton.isEnabled = true
            result.text = "Ready. Tap ANALYZE PDF."
        }
    }

    private fun analyzePdf() {
        val uri = selectedUri ?: return

        analyzeButton.isEnabled = false
        result.text = "Analyzing PDF…\nThis may take a moment for large documents."

        executor.execute {
            try {
                contentResolver.openInputStream(uri).use { input ->
                    if (input == null) {
                        throw IOException("Could not open the selected PDF.")
                    }

                    PDDocument.load(input).use { document ->
                        val pageCount = document.numberOfPages
                        val stripper = PDFTextStripper()

                        // V0.2 deliberately analyzes only the first page.
                        // Later versions will process pages independently.
                        stripper.startPage = 1
                        stripper.endPage = minOf(1, pageCount)

                        val text = stripper.getText(document).trim()

                        val preview = if (text.length > MAX_PREVIEW) {
                            text.take(MAX_PREVIEW) + "\n\n[Preview truncated]"
                        } else {
                            text
                        }

                        runOnUiThread {
                            analyzeButton.isEnabled = true
                            result.text = buildString {
                                append("PDF ANALYSIS\n")
                                append("──────────────\n")
                                append("Pages: $pageCount\n")
                                append("Analyzed page: 1\n\n")
                                append("EXTRACTED TEXT\n")
                                append("──────────────\n")
                                if (preview.isBlank()) {
                                    append("[No text extracted from page 1]\n")
                                    append("\nThis may be an image/scanned page or a PDF with text-extraction limitations.")
                                } else {
                                    append(preview)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    analyzeButton.isEnabled = true
                    result.text = "PDF ANALYSIS FAILED\n\n${e.javaClass.simpleName}: ${e.message ?: "Unknown error"}"
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_PDF = 1001
        private const val MAX_PREVIEW = 12000
    }
}
