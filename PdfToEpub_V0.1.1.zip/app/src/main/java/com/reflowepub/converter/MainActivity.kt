package com.reflowepub.converter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB"
            textSize = 28f
        }

        val subtitle = TextView(this).apply {
            text = "V0.1.1 — Build foundation"
            textSize = 16f
        }

        val button = Button(this).apply {
            text = "Select PDF"
            setOnClickListener { selectPdf() }
        }

        status = TextView(this).apply {
            text = "No PDF selected"
            textSize = 16f
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(button)
        layout.addView(status)

        setContentView(layout)
    }

    private fun selectPdf() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/pdf"
        }
        startActivityForResult(intent, REQUEST_PDF)
    }

    @Deprecated("Simple V0.1.1 activity-result flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_PDF && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                status.text = "Selected PDF:\n${uri.lastPathSegment ?: uri}"
            }
        }
    }

    companion object {
        private const val REQUEST_PDF = 1001
    }
}
