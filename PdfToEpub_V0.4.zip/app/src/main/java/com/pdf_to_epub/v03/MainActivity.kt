package com.pdf_to_epub.v03

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.4 — Text + layout repair"
            textSize = 28f
        }

        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE LAYOUT" }

        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(
            ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 0, 1f)
        )
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, 100
            )
        }

        analyze.setOnClickListener {
            selectedUri?.let { analyzePdf(it) }
                ?: run { output.text = "Please select a PDF first." }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            try {
                data?.data?.let {
                    contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            } catch (_: Exception) {}
            output.text = "Selected PDF:\n${selectedUri ?: ""}"
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Analyzing text and layout…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeFirstPage(it) }
                    ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread {
                    output.text = "Analysis error:\n${e.javaClass.simpleName}: ${e.message}"
                }
            }
        }.start()
    }

    private fun analyzeFirstPage(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val stripper = LayoutStripper()
            stripper.startPage = 1
            stripper.endPage = 1
            stripper.sortByPosition = true
            // Do not call super.processTextPosition(): this screen is collecting
            // its own character-level representation and does not need PDFBox's
            // default text output.
            stripper.getText(doc)

            val cleaned = deduplicateCharacters(stripper.items)
            val lines = buildLines(cleaned)
            val blocks = buildBlocks(lines)

            val sb = StringBuilder()
            sb.append("Pages: ${doc.numberOfPages}\n")
            sb.append("Analyzed page: 1\n")
            sb.append("Raw text items: ${stripper.items.size}\n")
            sb.append("After duplicate cleanup: ${cleaned.size}\n")
            sb.append("Detected lines: ${lines.size}\n")
            sb.append("Estimated blocks: ${blocks.size}\n\n")

            sb.append("RECONSTRUCTED TEXT\n")
            sb.append("-----------------\n")
            lines.forEach { line ->
                sb.append(line.text.trim()).append('\n')
            }

            sb.append("\nLAYOUT BLOCKS\n")
            sb.append("-------------\n")
            blocks.forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1}\n")
                sb.append("x=${fmt(b.x)}  y=${fmt(b.y)}  w=${fmt(b.w)}  h=${fmt(b.h)}\n")
                sb.append("font≈${fmt(b.fontSize)}\n")
                sb.append("text: ${b.text.trim()}\n\n")
            }
            return sb.toString()
        }
    }

    data class Item(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float
    )

    data class Line(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class Block(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()

        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: return
            if (s.isNotEmpty() && s.any { !it.isWhitespace() }) {
                items.add(
                    Item(
                        text = s,
                        x = text.xDirAdj,
                        y = text.yDirAdj,
                        w = text.widthDirAdj,
                        h = text.heightDir,
                        fontSize = text.fontSizeInPt
                    )
                )
            }
            // Intentionally no super call. We only need the positioned
            // characters for reconstruction.
        }
    }

    private fun deduplicateCharacters(items: List<Item>): List<Item> {
        if (items.isEmpty()) return emptyList()

        // Some PDFs contain duplicate text glyphs (often an invisible/search
        // layer over visible text). Remove glyphs that occupy essentially the
        // same position and represent the same character.
        val result = mutableListOf<Item>()

        for (item in items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })) {
            val duplicate = result.any { old ->
                old.text == item.text &&
                    abs(old.x - item.x) <= 0.8f &&
                    abs(old.y - item.y) <= 0.8f &&
                    abs(old.fontSize - item.fontSize) <= 1.0f
            }
            if (!duplicate) result.add(item)
        }
        return result
    }

    private fun buildLines(items: List<Item>): List<Line> {
        if (items.isEmpty()) return emptyList()

        val sorted = items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })
        val lines = mutableListOf<MutableList<Item>>()

        for (item in sorted) {
            val target = lines.lastOrNull { line ->
                val avgY = line.map { it.y }.average().toFloat()
                val avgH = line.map { it.h }.average().toFloat()
                abs(item.y - avgY) <= max(2.5f, avgH * 0.55f)
            }

            if (target == null) lines.add(mutableListOf(item))
            else target.add(item)
        }

        return lines.map { chars ->
            val ordered = chars.sortedBy { it.x }
            var text = ""
            var previous: Item? = null

            for (c in ordered) {
                if (previous != null) {
                    val gap = c.x - (previous.x + previous.w)
                    val spaceThreshold = max(1.2f, minOf(c.fontSize, previous.fontSize) * 0.22f)
                    if (gap > spaceThreshold) text += " "
                }
                text += c.text
                previous = c
            }

            val left = ordered.minOf { it.x }
            val right = ordered.maxOf { it.x + it.w }
            val top = ordered.minOf { it.y }
            val bottom = ordered.maxOf { it.y + it.h }
            val font = ordered.map { it.fontSize }.average().toFloat()

            Line(text, left, top, right - left, bottom - top, font)
        }.sortedBy { it.y }
    }

    private fun buildBlocks(lines: List<Line>): List<Block> {
        if (lines.isEmpty()) return emptyList()

        val blocks = mutableListOf<Block>()
        for (line in lines) {
            val previous = blocks.lastOrNull()

            if (previous != null) {
                val verticalGap = line.y - (previous.y + previous.h)
                val sameColumn = abs(line.x - previous.x) <= max(18f, line.fontSize * 2.5f)
                val similarFont = abs(line.fontSize - previous.fontSize) <= max(2.5f, previous.fontSize * 0.25f)

                if (verticalGap <= max(10f, line.fontSize * 0.9f) && sameColumn && similarFont) {
                    previous.text += " " + line.text
                    val right = line.x + line.w
                    previous.w = max(previous.w, right - previous.x)
                    previous.h = max(previous.h, line.y + line.h - previous.y)
                    previous.fontSize = (previous.fontSize + line.fontSize) / 2f
                    continue
                }
            }

            blocks.add(
                Block(
                    line.text,
                    line.x,
                    line.y,
                    line.w,
                    line.h,
                    line.fontSize
                )
            )
        }
        return blocks
    }

    private fun fmt(v: Float): String =
        String.format(Locale.US, "%.1f", v)
}
