package com.pdf_to_epub.v03

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.3 — Layout analysis"
            textSize = 28f
        }

        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE LAYOUT" }
        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, 100
            )
        }

        analyze.setOnClickListener {
            val uri = selectedUri
            if (uri == null) {
                output.text = "Please select a PDF first."
            } else {
                analyzePdf(uri)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            output.text = "Selected PDF:\n${selectedUri ?: ""}"
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Analyzing layout…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeFirstPage(it) }
                    ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Analysis error:\n${e.message}" }
            }
        }.start()
    }

    private fun analyzeFirstPage(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val stripper = LayoutStripper()
            stripper.startPage = 1
            stripper.endPage = 1
            stripper.sortByPosition = true
            stripper.getText(doc)

            val blocks = buildBlocks(stripper.items)
            val sb = StringBuilder()
            sb.append("Pages: ${doc.numberOfPages}\n")
            sb.append("Analyzed page: 1\n")
            sb.append("Text items: ${stripper.items.size}\n")
            sb.append("Estimated blocks: ${blocks.size}\n\n")

            blocks.forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1}\n")
                sb.append("x=${"%.1f".format(b.x)}  y=${"%.1f".format(b.y)}  ")
                sb.append("w=${"%.1f".format(b.w)}  h=${"%.1f".format(b.h)}\n")
                sb.append("font≈${"%.1f".format(b.fontSize)}\n")
                sb.append("text: ${b.text.trim()}\n\n")
            }
            return sb.toString()
        }
    }

    data class Item(val text: String, val x: Float, val y: Float, val w: Float, val h: Float, val fontSize: Float)
    data class Block(var text: String, var x: Float, var y: Float, var w: Float, var h: Float, var fontSize: Float)

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()
        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: ""
            if (s.isNotBlank()) {
                items.add(Item(
                    s, text.xDirAdj, text.yDirAdj,
                    text.widthDirAdj, text.heightDir,
                    text.fontSizeInPt
                ))
            }
            super.processTextPosition(text)
        }
    }

    private fun buildBlocks(items: List<Item>): List<Block> {
        if (items.isEmpty()) return emptyList()

        val sorted = items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })
        val blocks = mutableListOf<Block>()

        for (item in sorted) {
            val previous = blocks.lastOrNull()
            if (previous != null &&
                abs(item.y - previous.y) <= maxOf(4f, item.h * 0.65f) &&
                item.x <= previous.x + previous.w + maxOf(18f, item.fontSize * 2.5f)
            ) {
                previous.text += item.text
                val right = item.x + item.w
                previous.w = maxOf(previous.w, right - previous.x)
                previous.h = maxOf(previous.h, item.h)
                previous.fontSize = (previous.fontSize + item.fontSize) / 2f
            } else {
                blocks.add(Block(item.text, item.x, item.y, item.w, item.h, item.fontSize))
            }
        }
        return blocks
    }
}
